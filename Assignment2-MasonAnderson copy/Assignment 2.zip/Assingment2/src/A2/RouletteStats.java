package A2;

import java.util.Scanner;


public class RouletteStats {
    public final static int START_CREDITS = 100;
    public final static int BET_AMOUNT = 1;
    
    
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        while(true) {
            System.out.println("Please enter 'p' to simulate sessions");
            System.out.println("or 'q' to quit");
            String myLet = keyboard.nextLine();
            if(myLet.charAt(0) == 'p') {
                //Get number of sessions
                System.out.println("Please enter how many sessions you want to play");
				String x = keyboard.nextLine();
				int numSessions = Integer.parseInt(x);
                
                //Get number of bets
                System.out.println("Please enter how many bets you want to place");
				x = keyboard.nextLine();
				int numBets = Integer.parseInt(x);
                
                //Get bet type
                System.out.println("Please enter the bet type you want to place");
				String betType = keyboard.nextLine();
                RouletteStats.playManySessions(betType, numBets, numSessions);
				
            }
            else if(myLet.charAt(0) == 'q') {
                break;
            }
            
        }
        keyboard.close();
    }
    
    /**
     * Simulates a session of bets using a uniform betting strategy.
     *   @param betType the type of bet ("red", "black", "odd", "even", or "1".."36")
     *   @param numBets the number of bets to be carried out in this session
     *   @return the number of credits won or lost during the round
     */
    public static int playSession(String betType, int numBets) {
        RouletteGame game = new RouletteGame();
        game.addCredits(RouletteStats.START_CREDITS);
        int nextBet = RouletteStats.BET_AMOUNT;
        for (int betNum = 0; betNum < numBets; betNum++) {
            String result = game.makeBet(nextBet, betType);
            System.out.println(result);
            
            if (result.contains("LOSE")) {
                nextBet *= 2;  
                if (game.checkCredits() < nextBet) {
                    System.out.println("Out of credits. Stopping Martingale strategy.");
                    break;
                }
            } else {
                nextBet = RouletteStats.BET_AMOUNT;  // Reset the bet to the initial amount after a win
            }
        }
        return game.checkCredits() - RouletteStats.START_CREDITS;
    }


    /**
     * Simulates a number of sessions of betting and displays statistics.
     *   @param betType the type of bet ("red", "black", "odd", "even", or "1".."36")
     *   @param numBets the number of bets in each session
     *   @param numSessions the number of sessions to simulate
     */
    public static void playManySessions(String betType, int numBets, int numSessions) {
        int numLosingSessions = 0;
        int totalAmountLost = 0;
        int maxAmountLost = 0;
        for (int sessionNum = 0; sessionNum < numSessions; sessionNum++) {
            int result = RouletteStats.playSession(betType, numBets);            
            if (result < 0) {
                numLosingSessions++;
                if (-result > maxAmountLost) {
                    maxAmountLost = -result;
                }
            }
            totalAmountLost -= result;
        }
        
        System.out.println(numSessions + " sessions, with " + 
                           numBets + " bets per session on " + betType + ":");
        double lossPercent = 100.0*numLosingSessions / numSessions;
        System.out.println("    Loss percentage = " + lossPercent + " %");
        double avgAmountLost = (double)totalAmountLost / numSessions;
        System.out.println("    Avg lost per session = " + avgAmountLost);
        System.out.println("    Maximum lost = " + maxAmountLost);
    }
}

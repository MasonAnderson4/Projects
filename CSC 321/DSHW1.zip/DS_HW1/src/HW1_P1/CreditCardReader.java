package HW1_P1;

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class CreditCardReader {
	
	//method to read each line and store without any spaces or dashes
	//parameters: String of the filename
	//returns: An array list with the credit card numbers as longs
	public ArrayList<String> readFile(String filename) {
		File file = new File(filename);
		ArrayList<String> numberList = new ArrayList<String>();
		
		
		try(Scanner scanner = new Scanner(file)){
			while(scanner.hasNextLine()) {
				String creditCardNumber = scanner.nextLine();
				creditCardNumber = creditCardNumber.replace(" ", "");
				creditCardNumber = creditCardNumber.replace("-", "");
				
				numberList.add(creditCardNumber);
				
			}
		}
		catch(FileNotFoundException e) {
			System.out.print("Error: " + filename + "not found.");
		}
		
		LuhnAlgorithm experiment = new LuhnAlgorithm();
		experiment.luhnAlgorithm(numberList);
		
		return numberList;
	}

}

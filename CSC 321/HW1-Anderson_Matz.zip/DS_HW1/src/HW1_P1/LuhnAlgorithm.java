package HW1_P1;

import java.util.ArrayList;

//Authors: Mason Anderson and William Matz
//Date: January 19, 2024

public class LuhnAlgorithm {
	
	//method to perform Luhn Algorithm on a string
	//parameters: an array list of the numbers as Strings
	//returns: whether the credit card number is valid or invalid
		public void luhnAlgorithm(ArrayList<String> list) {
			
			for(int i = 0; i < list.size(); i ++) {
				int total = 0;
				String individualNumber = list.get(i);
				
				if (individualNumber.length() % 2 == 0) {
					for(int j = 0; j < individualNumber.length(); j++) {
						int digit = Character.getNumericValue(individualNumber.charAt(j));
						if(j % 2 == 0 || j == 0) {
							digit *= 2;
							if(digit >= 10) {
								int firstDigit = digit/10;
								int secondDigit = digit%10;
								total += firstDigit + secondDigit;
							}
							else {
								total += digit;
							}
						}
						else {
							total += digit;
						}
					}
				}
				else {
					for(int j = 0; j < individualNumber.length(); j++) {
						int digit = Character.getNumericValue(individualNumber.charAt(j));
						if(j % 2 == 0 || j == 0) {
							total += digit;
						}
						else {
							digit *= 2;
							if(digit >= 10) {
								int firstDigit = digit/10;
								int secondDigit = digit%10;
								total += firstDigit + secondDigit;
							}
							else {
								total += digit;
							}
						}
					}
				}
				if(total % 10 == 0) {
					System.out.println(list.get(i) + " VALID");
				}
				else {
					System.out.println(list.get(i) + " INVALID");
				}
			}
		}
}

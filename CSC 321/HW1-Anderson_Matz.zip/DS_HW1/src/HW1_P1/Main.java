package HW1_P1;

import java.util.Scanner;


//Authors: Mason Anderson and William Matz
//Date: January 19, 2024

public class Main {
	
	public static void main(String[] args) {
		CreditCardReader reader = new CreditCardReader();
		Scanner console = new Scanner(System.in);
		System.out.println("Insert file name of credit card numbers: ");
		String fileName = console.next();
		reader.readFile(fileName);
	}

}

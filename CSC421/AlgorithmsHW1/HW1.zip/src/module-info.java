/**
 * 
 */
/**
 * 
 */
module AlgorithmsHW1 {
}